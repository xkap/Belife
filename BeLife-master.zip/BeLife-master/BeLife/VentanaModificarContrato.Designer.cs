﻿namespace BeLife
{
    partial class VentanaModificarContrato
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VentanaModificarContrato));
            this.PanelResultados = new System.Windows.Forms.Panel();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.LblIniVig = new System.Windows.Forms.Label();
            this.LblPoliza = new System.Windows.Forms.Label();
            this.LblTitular = new System.Windows.Forms.Label();
            this.LblPrimaAnual = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.LblPrimaMensual = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TxtObservaciones = new System.Windows.Forms.TextBox();
            this.RadioNo = new System.Windows.Forms.RadioButton();
            this.RadioSi = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ComboPlan = new System.Windows.Forms.ComboBox();
            this.LblNumContrato = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.PanelPrincipal = new System.Windows.Forms.Panel();
            this.BtnVolver = new System.Windows.Forms.Button();
            this.TxtNumero = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnModificar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.PanelResultados.SuspendLayout();
            this.PanelPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelResultados
            // 
            this.PanelResultados.Controls.Add(this.BtnCancelar);
            this.PanelResultados.Controls.Add(this.LblIniVig);
            this.PanelResultados.Controls.Add(this.LblPoliza);
            this.PanelResultados.Controls.Add(this.LblTitular);
            this.PanelResultados.Controls.Add(this.LblPrimaAnual);
            this.PanelResultados.Controls.Add(this.label12);
            this.PanelResultados.Controls.Add(this.LblPrimaMensual);
            this.PanelResultados.Controls.Add(this.label10);
            this.PanelResultados.Controls.Add(this.label9);
            this.PanelResultados.Controls.Add(this.label8);
            this.PanelResultados.Controls.Add(this.TxtObservaciones);
            this.PanelResultados.Controls.Add(this.RadioNo);
            this.PanelResultados.Controls.Add(this.RadioSi);
            this.PanelResultados.Controls.Add(this.label7);
            this.PanelResultados.Controls.Add(this.label6);
            this.PanelResultados.Controls.Add(this.label5);
            this.PanelResultados.Controls.Add(this.ComboPlan);
            this.PanelResultados.Controls.Add(this.LblNumContrato);
            this.PanelResultados.Controls.Add(this.label4);
            this.PanelResultados.Controls.Add(this.label11);
            this.PanelResultados.Controls.Add(this.groupBox1);
            this.PanelResultados.Controls.Add(this.BtnAceptar);
            this.PanelResultados.Controls.Add(this.label3);
            this.PanelResultados.Location = new System.Drawing.Point(9, 55);
            this.PanelResultados.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PanelResultados.Name = "PanelResultados";
            this.PanelResultados.Size = new System.Drawing.Size(485, 462);
            this.PanelResultados.TabIndex = 1;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Location = new System.Drawing.Point(67, 411);
            this.BtnCancelar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(120, 31);
            this.BtnCancelar.TabIndex = 55;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.button1_Click);
            // 
            // LblIniVig
            // 
            this.LblIniVig.AutoSize = true;
            this.LblIniVig.Location = new System.Drawing.Point(181, 145);
            this.LblIniVig.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblIniVig.Name = "LblIniVig";
            this.LblIniVig.Size = new System.Drawing.Size(19, 13);
            this.LblIniVig.TabIndex = 54;
            this.LblIniVig.Text = "----";
            // 
            // LblPoliza
            // 
            this.LblPoliza.AutoSize = true;
            this.LblPoliza.Location = new System.Drawing.Point(178, 212);
            this.LblPoliza.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPoliza.Name = "LblPoliza";
            this.LblPoliza.Size = new System.Drawing.Size(19, 13);
            this.LblPoliza.TabIndex = 53;
            this.LblPoliza.Text = "----";
            // 
            // LblTitular
            // 
            this.LblTitular.AutoSize = true;
            this.LblTitular.Location = new System.Drawing.Point(181, 106);
            this.LblTitular.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblTitular.Name = "LblTitular";
            this.LblTitular.Size = new System.Drawing.Size(19, 13);
            this.LblTitular.TabIndex = 52;
            this.LblTitular.Text = "----";
            // 
            // LblPrimaAnual
            // 
            this.LblPrimaAnual.AutoSize = true;
            this.LblPrimaAnual.Location = new System.Drawing.Point(188, 349);
            this.LblPrimaAnual.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPrimaAnual.Name = "LblPrimaAnual";
            this.LblPrimaAnual.Size = new System.Drawing.Size(19, 13);
            this.LblPrimaAnual.TabIndex = 51;
            this.LblPrimaAnual.Text = "----";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 349);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 13);
            this.label12.TabIndex = 50;
            this.label12.Text = "Prima Anual:";
            // 
            // LblPrimaMensual
            // 
            this.LblPrimaMensual.AutoSize = true;
            this.LblPrimaMensual.Location = new System.Drawing.Point(188, 384);
            this.LblPrimaMensual.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPrimaMensual.Name = "LblPrimaMensual";
            this.LblPrimaMensual.Size = new System.Drawing.Size(19, 13);
            this.LblPrimaMensual.TabIndex = 49;
            this.LblPrimaMensual.Text = "----";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 384);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 48;
            this.label10.Text = "Prima Mensual:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 212);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 47;
            this.label9.Text = "Póliza";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 300);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 45;
            this.label8.Text = "Observaciones";
            // 
            // TxtObservaciones
            // 
            this.TxtObservaciones.Location = new System.Drawing.Point(181, 300);
            this.TxtObservaciones.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtObservaciones.Name = "TxtObservaciones";
            this.TxtObservaciones.Size = new System.Drawing.Size(233, 20);
            this.TxtObservaciones.TabIndex = 44;
            // 
            // RadioNo
            // 
            this.RadioNo.AutoSize = true;
            this.RadioNo.Location = new System.Drawing.Point(317, 255);
            this.RadioNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RadioNo.Name = "RadioNo";
            this.RadioNo.Size = new System.Drawing.Size(41, 17);
            this.RadioNo.TabIndex = 42;
            this.RadioNo.TabStop = true;
            this.RadioNo.Text = "NO";
            this.RadioNo.UseVisualStyleBackColor = true;
            // 
            // RadioSi
            // 
            this.RadioSi.AutoSize = true;
            this.RadioSi.Location = new System.Drawing.Point(191, 255);
            this.RadioSi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RadioSi.Name = "RadioSi";
            this.RadioSi.Size = new System.Drawing.Size(35, 17);
            this.RadioSi.TabIndex = 41;
            this.RadioSi.TabStop = true;
            this.RadioSi.Text = "SI";
            this.RadioSi.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 255);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "Declaración de Salud";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 106);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Titular";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 179);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 13);
            this.label5.TabIndex = 37;
            this.label5.Text = "Plan";
            // 
            // ComboPlan
            // 
            this.ComboPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboPlan.FormattingEnabled = true;
            this.ComboPlan.Location = new System.Drawing.Point(181, 176);
            this.ComboPlan.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ComboPlan.Name = "ComboPlan";
            this.ComboPlan.Size = new System.Drawing.Size(228, 21);
            this.ComboPlan.TabIndex = 36;
            // 
            // LblNumContrato
            // 
            this.LblNumContrato.AutoSize = true;
            this.LblNumContrato.Location = new System.Drawing.Point(181, 73);
            this.LblNumContrato.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblNumContrato.Name = "LblNumContrato";
            this.LblNumContrato.Size = new System.Drawing.Size(19, 13);
            this.LblNumContrato.TabIndex = 35;
            this.LblNumContrato.Text = "----";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 74);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Número de Contrato:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 143);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "Inicio Vigencia";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(181, 241);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(217, 42);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.Location = new System.Drawing.Point(241, 411);
            this.BtnAceptar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(120, 31);
            this.BtnAceptar.TabIndex = 31;
            this.BtnAceptar.Text = "Aceptar";
            this.BtnAceptar.UseVisualStyleBackColor = true;
            this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 19);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(382, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "El contrato se encuentra registrado y puede ser modificado";
            // 
            // PanelPrincipal
            // 
            this.PanelPrincipal.Controls.Add(this.BtnVolver);
            this.PanelPrincipal.Controls.Add(this.TxtNumero);
            this.PanelPrincipal.Controls.Add(this.label2);
            this.PanelPrincipal.Controls.Add(this.BtnModificar);
            this.PanelPrincipal.Location = new System.Drawing.Point(9, 55);
            this.PanelPrincipal.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PanelPrincipal.Name = "PanelPrincipal";
            this.PanelPrincipal.Size = new System.Drawing.Size(488, 384);
            this.PanelPrincipal.TabIndex = 6;
            // 
            // BtnVolver
            // 
            this.BtnVolver.Location = new System.Drawing.Point(53, 293);
            this.BtnVolver.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnVolver.Name = "BtnVolver";
            this.BtnVolver.Size = new System.Drawing.Size(155, 34);
            this.BtnVolver.TabIndex = 5;
            this.BtnVolver.Text = "Volver";
            this.BtnVolver.UseVisualStyleBackColor = true;
            this.BtnVolver.Click += new System.EventHandler(this.BtnVolver_Click);
            // 
            // TxtNumero
            // 
            this.TxtNumero.Location = new System.Drawing.Point(120, 163);
            this.TxtNumero.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtNumero.Name = "TxtNumero";
            this.TxtNumero.Size = new System.Drawing.Size(251, 20);
            this.TxtNumero.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(144, 125);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(205, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Numero de Contrato:";
            // 
            // BtnModificar
            // 
            this.BtnModificar.Location = new System.Drawing.Point(232, 293);
            this.BtnModificar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnModificar.Name = "BtnModificar";
            this.BtnModificar.Size = new System.Drawing.Size(155, 34);
            this.BtnModificar.TabIndex = 7;
            this.BtnModificar.Text = "Modificar";
            this.BtnModificar.UseVisualStyleBackColor = true;
            this.BtnModificar.Click += new System.EventHandler(this.BtnModificar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(136, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 31);
            this.label1.TabIndex = 4;
            this.label1.Text = "Modificar Contrato";
            // 
            // VentanaModificarContrato
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(509, 533);
            this.Controls.Add(this.PanelResultados);
            this.Controls.Add(this.PanelPrincipal);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "VentanaModificarContrato";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VentanaModificarContrato";
            this.PanelResultados.ResumeLayout(false);
            this.PanelResultados.PerformLayout();
            this.PanelPrincipal.ResumeLayout(false);
            this.PanelPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PanelResultados;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel PanelPrincipal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtNumero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnVolver;
        private System.Windows.Forms.Button BtnModificar;
        private System.Windows.Forms.Label LblPrimaAnual;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label LblPrimaMensual;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TxtObservaciones;
        private System.Windows.Forms.RadioButton RadioNo;
        private System.Windows.Forms.RadioButton RadioSi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ComboPlan;
        private System.Windows.Forms.Label LblNumContrato;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LblTitular;
        private System.Windows.Forms.Label LblPoliza;
        private System.Windows.Forms.Label LblIniVig;
        private System.Windows.Forms.Button BtnCancelar;
    }
}