# BeLife
Fictional project of an insurance company in Spanish. No database connection used. This was a university assignment.
You can clone it if you want.

### This project was created in the 3rd semester of my CS course using C# and the way it was coded is different as how I would do it now.
